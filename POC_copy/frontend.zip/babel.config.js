module.exports = {
    presets: [
      'react-app'
    ],
    plugins: [
      '@babel/plugin-proposal-private-property-in-object'
    ]
  }
  