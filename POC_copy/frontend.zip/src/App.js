import React, { Component } from "react";
import { w3cwebsocket as W3CWebSocket } from "websocket";

import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import Container from '@mui/material/Container';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import Paper from '@mui/material/Paper';

import { createTheme } from "@mui/system";

const theme = createTheme();

class App extends Component {
  state = {
    filledForm: false,
    messages: [],
    value: "",
    name: "",
    room: "test",
    client: null,
  };

  establishWebSocketConnection = () => {
    const { room } = this.state;
    const client = new W3CWebSocket("ws://127.0.0.1:8000/ws/" + room + "/");
    client.onopen = () => {
      console.log("WebSocket Client Connected");
    };
    client.onmessage = (message) => {
      const dataFromServer = JSON.parse(message.data);
      if (dataFromServer) {
        this.setState((state) => ({
          messages: [
            ...state.messages,
            {
              msg: dataFromServer.text,
              name: dataFromServer.sender,
            },
          ],
        }));
      }
    };
    this.setState({ client });
  };

  onButtonClicked = (e) => {
    const { client, value, name } = this.state;
    client.send(
      JSON.stringify({
        type: "message",
        text: value,
        sender: name,
      })
    );
    this.setState({ value: "" });
    e.preventDefault();
  };

  onSubmit = (e) => {
    e.preventDefault();
    this.setState(
      {
        filledForm: true,
      },
      () => {
        this.establishWebSocketConnection();
      }
    );
  };

  render() {
    const { filledForm, messages, value, room } = this.state;

    return (
      <Container component="main" maxWidth="xs">
        {filledForm ? (
          <div style={{ marginTop: 50 }}>
            Room Name: {room}
            <Paper
              style={{
                height: 500,
                maxHeight: 500,
                overflow: "auto",
                boxShadow: "none",
              }}
            >
              {messages.map((message, index) => (
                <Card key={index}>
                  <CardHeader title={message.name} subheader={message.msg} />
                </Card>
              ))}
            </Paper>
            <form noValidate onSubmit={this.onButtonClicked}>
              <TextField
                id="outlined-helperText"
                label="Write text"
                defaultValue="Default Value"
                variant="outlined"
                value={value}
                fullWidth
                onChange={(e) => {
                  this.setState({ value: e.target.value });
                }}
              />
              <Button
                type="submit"
                fullWidth
                variant="contained"
                color="primary"
                sx={{
                  margin: theme.spacing(3, 0, 2),
                }}
              >
                Send Message
              </Button>
            </form>
          </div>
        ) : (
          <div>
            <CssBaseline />
            <div>
              <form noValidate onSubmit={this.onSubmit}>
                <TextField
                  variant="outlined"
                  margin="normal"
                  required
                  fullWidth
                  label="Room name"
                  name="Room name"
                  autoFocus
                  value={room}
                  onChange={(e) => {
                    this.setState({ room: e.target.value });
                  }}
                />
                <TextField
                  variant="outlined"
                  margin="normal"
                  required
                  fullWidth
                  name="sender"
                  label="sender"
                  type="sender"
                  id="sender"
                  value={this.state.name}
                  onChange={(e) => {
                    this.setState({ name: e.target.value });
                  }}
                />
                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  color="primary"
                  sx={{
                    margin: theme.spacing(3, 0, 2),
                  }}
                >
                  Submit
                </Button>
              </form>
            </div>
          </div>
        )}
      </Container>
    );
  }
}

export default App;
